<footer class="container-fluid bg-body-tertiary {{ $fixedBottom ?? 'fixed-bottom' }}">
    <div class="row text-center pt-2">
        <p>&copy; Wycieczki górskie &ndash; 2025</p>
    </div>
  </footer>
